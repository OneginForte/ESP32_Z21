/************************************************************************************
 Z21 Ethernet DCC Command Station Interface config file 
 Copyright (c) 2015-2021 by Philipp Gahtow 
***********************************************************************************/

/*-------------**********************************-----------------------------------
/ ************* CHANGE DOWN HERE THE CONFIGURATION ***************
/ -------------**********************************-----------------------------------*/
/* Command Station Config: */
/* => uncomment ("//" or #undef) the following lines, if you not USE the Interface! */
/*----------------------------------------------------------------------------------*/

/***************************************************************

 S88 Bus Interface 

***************************************************************/

/* activate singel line S88N Interface (max 62 * 8 Module)*/
#define S88N


/***************************************************************
 
  Z21 LAN WiFi Interface über Serial-Port für Arduino UNO/MEGA/DUE (ESP 8266)
 
**************************************************************/

/* activate WLAN Z21 Komunikation via Serial to ESP8266 */
#define WIFI

/* (DEFAULT = Serial2!) use not the standard WLAN Serial Interface. Select another serial: */
//#define WLAN Serial2

/* WiFi over SoftSerial for UNO only! - LAN and LocoNet will be inaktiv! */
//#define Z21VIRTUAL  


/***************************************************************

 Config for stand alone Z21 Central Station
 based on ESP8266 or ESP32 Board

***************************************************************/

/* (DEFAULT!) Change default Z21 AP (SSID) */
//#define SssidAP "Z21_ESP_Central"   

/* (DEFAULT!) Change default Z21 network password */
//#define SpassAP "12345678"  

/* (DEFAULT!) Change default Kanal des AP */
//#define SkanalAP 3          



/**************************************************************

 LAN Ethernet Z21 LAN Kommunikation
 mit W5100 oder ENC28 Ethernet Shield
 (not for ESP8266 and ESP32)

***************************************************************/

/* Aktivieren des Ethernet LAN Interface */
#define LAN       //Standard IP ist 192.168.0.111. Bitte diese IP nur über die Webseite (http://192.168.0.111) ändern!

/* USE a ENC28J60 module - instead of w5100 Shield (for MEGA only!) */
//#define ENC28   

/* Activate to Receive a IP Adress from the DHCP Server, if no DHCP found fix IP Adress vom EEPROM will be load.*/
//#define DHCP      

/* Website to configure IP Adress and Number of S88 Bus Module*/
//#define HTTPCONF  

/* (DEFAULT = 84:2B:BC:EF:FE:ED!) change optional LAN MAC Address. MAC starts with: „84:2B:BC:..Byte*2..:..Byte*1..:..Byte*0..“*/
//#define LANmacB2 0xEF   //Byte2
//#define LANmacB1 0xFE   //Byte1
//#define LANmacB0 0xED   //Byte0

/* (DEFAULT!) Timeout to wait for a DHCP respose (Fix default Time: 5 sec) */
//#define LANTimeoutDHCP 10000 


/***************************************************************

 DCC RailCom Global Detector
 (not for ESP8266 and ESP32)

***************************************************************/

/* activate the DCC Railcom Global Detector for MEGA on Serial Port 3 (RX only) */
#define DCCGLOBALDETECTOR  


/***************************************************************

 XpressNet Master/Salve Interface
 (not for ESP8266 and ESP32)

***************************************************************/

/* activate the XpressNet Interface */
#define XPRESSNET 


/***************************************************************

 LocoNet Interface 
 (Timer1, Timer5 on MEGA, with LocoNet2 Library on ESP32)

***************************************************************/

/* activate the LocoNet Interface */
#define LOCONET  

/* LocoNet Master-Mode: provide a Slot Server for Loco to use FRED */
//#define LnSLOTSRV                 

/* sende alle Lok-Ereignisse ins LocoNet (MASTER-MODE only) - default: false*/
//#define TXAllLokInfoOnLN true  //create a LocoNet Slot, even if not used with a LocoNet device!  


/***************************************************************

 External Booster Interface
 (zB. ROCO, CD[E])

***************************************************************/

/* activate external Booster support */
#define BOOSTER_EXT


/***************************************************************

 internal Booster Interface
 (zB. TLE5206)
***************************************************************/

/* activate internal Booster support */
#define BOOSTER_INT

/*(VAmpIntPin) activate the current sensor for prog track and SHORT CIRCUIT SENCE over MAINCURRENT:*/
#define BOOSTER_INT_MAINCURRENT   //Standard Short Circuit Detection over current sence resistor

/* (DEFAULT = 3!) Time after internal short circuit is detected (Fix default Value = 3) */
//#define DETECT_SHORT_INT_WAIT 3
  
/* (DEFAULT = 1000!) analogRead value for "mA" that is too much (Fix default Value = 400 (AREF 5.0V) and Value = 1000 (AREF 1.1V) */
//#define DETECT_SHORT_INT_VALUE  1000

/* (DEFAULT!) activate Short2 detection PIN reading (only one can be active!)*/
//#define BOOSTER_INT_TLE5206    //internal Booster with TLE5206
//#define BOOSTER_EXT_CDE        //external CDE Booster


/***************************************************************

 DCC Interface Configuration

***************************************************************/

/* default speed steps (Fahrstufen) => possible values are: FS14, FS28, FS128 */
#define FS128   

/* (DEFAULT = ROCO!) Define accessory Address start value => possivle values are: ROCO (+0), IB (+4) */
//#define SwitchFormat IB   


/***************************************************************

 Z21 System Data Configuration

***************************************************************/

/*Dallas 18B20 Temperatur Sensor for Arduino MEGA only! */
#define DALLASTEMPSENSE   //activate sensor, no temp resistor


/***************************************************************

 MCU 1.1V  Referenz Voltage Configuration

***************************************************************/

#define Uref 1.10                     // measured reference voltage ARef-pin, individual value for every Arduino
#define senseResist 0.33              // actual resistor for measuring current on track

//#define EXTERNAL_UREF_1V1   //AREF with external 1.1 Volt, to get better CV# read with Arduino UNO


/***************************************************************/
/*-------------------------------------------------------------*/
/*------------------DEBUG-ONLY---------------------------------*/
/*-------------------------------------------------------------*/
/***************************************************************/

/* Activate Debug on "Serial" with speed setting! */
#define DebugBaud 115200 

/*---------- select what to show: --------------*/
//#define DEBUG    //To see System-DATA on Serial
//#define DEBUG_WLAN_CONFIG  //to see config data of Wifi ESP8266 (IP, Pw, ..)
//#define REPORT    //To see Sensor Messages (LocoNet & S88)
//#define LnDEB    //To see RAW DATA of LocoNet Protokoll
//#define XnDEB    //To see XpressNet
//#define Z21DEBUG //to see Z21 LAN control data
//#define Z21DATADEBUG //to see RAW DATA of Z21 LAN Protokoll
//#define Z21SYSTEMDATADEBUG  //to see the system data mainpower and temp

/* (DEFAULT = Serial!) use not the Default Standard Debug Serial Interface. Select another serial: */
//#define Debug Serial

/***************************************************************/
/*-------------------------------------------------------------*/
/*-------------------Experimental-ONLY-------------------------*/
/*-------------------------------------------------------------*/
/***************************************************************/

/*DCC Decoder (only for MEGA, To decode a DCC-Signal, add this data to command station DCC output)*/
//#define DECODER   //outdated-not in use anymore!!!
