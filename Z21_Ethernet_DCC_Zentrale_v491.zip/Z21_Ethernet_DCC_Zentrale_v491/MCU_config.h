//--------------------------------------------------------------
/*
 * Setup up PIN-Configuration for different MCU
 * 
 * Support for:
 *    - Arduino DUE
 *    - Arduino ESP8266
 *    - Arduino UNO
 *    - Arduino MEGA  
 *    - Sanguino (ATmgega 644p & ATmega 1284p)
 * 
 * Copyright (c) by Philipp Gahtow, year 2021
*/

#if defined(__SAM3X8E__)    //SAM ARM Adruino DUE
#define DUE_MCU
#undef Z21VIRTUAL
#undef XPRESSNET

#elif defined(ESP8266) //ESP8266 or WeMos
#define ESP8266_MCU
#define ESP_WIFI
#define ESP_OTA
#undef Z21VIRTUAL
#undef LAN
#undef DHCP

#elif defined(ESP32)   //ESP32 Modul
#define ESP32_MCU
#define ESP_WIFI
#define ESP_OTA
#undef Z21VIRTUAL
#undef LAN
#undef DHCP
#undef WIFI

#elif defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__) //Arduino MEGA
#define MEGA_MCU
#undef Z21VIRTUAL

#elif defined(__AVR_ATmega1284P__) || defined(__AVR_ATmega644P__)  //Sanguino (other pins!)
#define SANGUINO_MCU
//ACHTUNG SS is on PIN3 (D2)!!!
#undef Z21VIRTUAL

#else //others Arduino UNO
#define UNO_MCU

#endif

//--------------------------------------------------------------
//Setting PIN CONFIG:
//--------------------------------------------------------------
#if defined(SANGUINO_MCU)
//Power:
#define Z21ResetPin 27  //RESET-Button-Pin bei Neustart betätigen um Standard IP zu setzten!
#define Z21ButtonPin Z21ResetPin  //Pin where the POWER-Button is conected
//DCC and Booster
#define DCCLed 25    //LED to show DCC active
#define DCCPin 12    //Pin for DCC sginal out
#define ShortLed 26     //LED to show Short
#define ShortExtPin 4  //Pin to detect Short Circuit of Booster (detect LOW)
#define GoExtPin 3   //Pin for GO/STOP Signal of Booster
#define ProgRelaisPin  23   //Pin for using Kehrschleifen-Modul
//Booster INT config:
#define GoIntPin 17   //Pin for inverted DCC Signal
#define ShortIntPin 13  //Pin for second Booster like TLE5206 (detect HIGH)
#define VAmpIntPin A4   //Input for Current sensor (CV read)
//XpressNet:
#define XNetTxRxPin  16    //XpressNet Control-Port for Send/Receive at MAX485
//LocoNet:
#define LNTxPin 15    //Sending Pin for LocoNet

//--------------------------------------------------------------
#elif defined(ESP8266_MCU)
//Power:
#define Z21ResetPin 0  //RESET-Button-Pin bei Neustart betätigen um Standard IP zu setzten!
#define Z21ButtonPin Z21ResetPin  //Pin where the POWER-Button is conected
//DCC and Booster
#define DCCLed 15    //LED to show DCC active
#define DCCPin 12    //Pin for DCC sginal out
#define ShortLed 99     //LED to show Short
#define ShortExtPin 13  //Pin to detect Short Circuit of Booster (detect LOW)
#define GoExtPin  99   //Pin for GO/STOP Signal of Booster
#define ProgRelaisPin  99   //Pin for using Kehrschleifen-Modul
//Booster INT config:
#define GoIntPin 14   //Pin for inverted DCC Signal
#define VAmpIntPin A0   //Input for Current sensor (CV read)

//--------------------------------------------------------------
#elif defined(ESP32_MCU)
//Power:
#define Z21ResetPin 36  //RESET-Button-Pin bei Neustart betätigen um Standard IP zu setzten!
#define Z21ButtonPin Z21ResetPin  //Pin where the POWER-Button is conected
//DCC and Booster
#define DCCLed 32    //LED to show DCC active
#define DCCPin 2    //Pin for DCC sginal out
#define ShortLed 26     //LED to show Short
#define ShortExtPin 4  //Pin to detect Short Circuit of Booster (detect LOW)
#define GoExtPin  15   //Pin for GO/STOP Signal of Booster
#define ProgRelaisPin  25   //Pin for using Kehrschleifen-Modul
//Booster INT config:
#define GoIntPin 33   //Pin for inverted DCC Signal
#define VAmpIntPin A0   //Input for Current sensor (CV read)
//XpressNet
//#define XNetTxRxPin  9    //XpressNet Control-Port for Send/Receive at MAX485
#undef XPRESSNET

//LocoNet
#define LNTxPin 21    //Sending Pin for LocoNet
#define LNRxPin 19    //Receiving Pin for LocoNet


//--------------------------------------------------------------
#elif defined(UNO_MCU) //Arduino UNO
//Power:
#define Z21ResetPin 10  //RESET-Button-Pin bei Neustart betätigen um Standard IP zu setzten!
#define Z21ButtonPin Z21ResetPin  //Pin where the POWER-Button is conected
//DCC and Booster
#define DCCLed 3    //LED to show DCC active
#define DCCPin 6    //Pin for DCC sginal out
#define additionalOutPin 11 //Pin for true DCC Output without Shutdown adn RailCom
#define ShortLed 45     //LED to show Short
#define ShortExtPin 5  //Pin to detect Short Circuit of Booster (detect LOW)
#define GoExtPin  A4   //Pin for GO/STOP Signal of Booster
#define ProgRelaisPin  A5   //Pin for using Kehrschleifen-Modul
//Booster INT config:
#define GoIntPin 4   //Pin for inverted DCC Signal
#define ShortIntPin 2  //Pin for second Booster like TLE5206 (detect HIGH)
#define VAmpIntPin A4   //Input for Current sensor
//XpressNet
#define XNetTxRxPin  9    //XpressNet Control-Port for Send/Receive at MAX485
//LocoNet
#define LNTxPin 7    //Sending Pin for LocoNet

//--------------------------------------------------------------
#else  //Arduino MEGA or DUE
//Power:
#define Z21ResetPin 47  //RESET-Button-Pin bei Neustart betätigen um Standard IP zu setzten!
#define Z21ButtonPin Z21ResetPin  //Pin where the POWER-Button is conected
//DCC and Booster
#define DCCLed 3    //LED to show DCC active
#define DCCPin 6    //Pin for DCC sginal out
#define additionalOutPin 11 //Pin for true DCC Output without Shutdown adn RailCom
#define ShortLed 45     //LED to show Short
#define ShortExtPin 5  //Pin to detect Short Circuit of Booster (detect LOW)
#define GoExtPin  A4   //Pin for GO/STOP Signal of Booster
#define ProgRelaisPin  A5   //Pin for using Kehrschleifen-Modul
//Booster INT config:
#define GoIntPin 39   //Pin for inverted DCC Signal
#define ShortIntPin 41  //Pin for second Booster like TLE5206 (detect HIGH)
#define VAmpIntPin A9   //Input for Current sensor (CV read)
//#define VAmSencePin A8  //AC 5A Sensor (for testing only)
#define VoltIntPin A10  //Rail Voltage: Rail:100k - Sence - 4,7k - GND
#define TempPin A11     //Temp.sence_resistor (15k) with 46k Pull-Up
//XpressNet
#define XNetTxRxPin  9    //XpressNet Control-Port for Send/Receive at MAX485
//LocoNet
#define LNTxPin 7    //Sending Pin for LocoNet

#endif

//--------------------------------------------------------------
//Dallas Temperatur Sensor:
#if defined(DALLASTEMPSENSE) && defined(MEGA_MCU)
#define ONE_WIRE_BUS A11  //2
#endif

//--------------------------------------------------------------
//S88 Singel Bus:
#if defined(ESP8266_MCU)
#undef S88N
#endif

#if defined(S88N)
#if defined(ESP32_MCU)
    //Eingänge:
  #define S88DataPin 13      //S88 Data IN
    //Ausgänge:
  #define S88ClkPin 12      //S88 Clock
  #define S88PSPin 14       //S88 PS/LOAD
  #define S88ResetPin 17    //S88 Reset
#else
    //Eingänge:
  #define S88DataPin A0      //S88 Data IN
    //Ausgänge:
  #define S88ClkPin A1      //S88 Clock
  #define S88PSPin A2       //S88 PS/LOAD
  #define S88ResetPin A3    //S88 Reset
#endif
#endif
//--------------------------------------------------------------
//DCC Decoder
#if defined(SANGUINO_MCU)
#undef DECODER
#endif
#if defined(ESP8266_MCU)
#undef DECODER
#endif
#if defined(ESP32_MCU)
#undef DECODER
#endif

   //Eingänge:
#if defined(DECODER)
#define IRQDCCPin 0      //Arduino Interrupt Number (attachInterrupt Funktion)
#define decDCCPin 2      //The Digital PIN where the Interrupt is on
#endif

//--------------------------------------------------------------
//LAN-Interface:
#define LANSSPIN 10   //Chip Select Pin of most Ethernet Shields
#define SDSSPIN 4     //Chip Select Pin SD-Card Reader on Ethernet Shield

//--------------------------------------------------------------
//Wifi-Interface:
#if defined (WIFI)
//Serialport:
#ifndef WLAN  //WLAN defined
  #if defined(MEGA_MCU) || defined(DUE_MCU) //MCU check: Arduino MEGA
  #define WLAN Serial2
  #elif defined(Z21VIRTUAL)
  #define WLAN SoftSerial
  #else
  #define WLAN Serial
  #endif  //END MCU check
#endif  //END WLAN defined

#if defined(Z21VIRTUAL) //Default Serial Baud Rate 1200,2400,4800,9600,14400,19200,28800,38400,57600,115200 
//for Arduino UNO only:
#define WIFISerialBaud 38400
#define RXvWiFi 12  //RX-PIN Soft Serial for Arduino UNO WiFi use  
#define TXvWiFi 13  //TX-PIN Soft Serial for Arduino UNO WiFi use  
#else
#define WIFISerialBaud 500000 //new with Z21_ESPArduinoUDP_v2.90 or higher!
#endif //END Z21VIRTUAL

#endif //End WiFi
